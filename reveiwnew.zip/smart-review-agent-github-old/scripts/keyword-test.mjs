// Checks business-wise keyword rules end to end (needs the app running with scripts/mock-gemini.mjs).
// BASE_URL=http://localhost:3000 ADMIN_PASSWORD=... node scripts/keyword-test.mjs
const BASE = process.env.BASE_URL || 'http://localhost:3000';
let pass = 0, fail = 0;
const ok = (name, cond, info = '') => {
  cond ? pass++ : fail++;
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${info ? '  — ' + info : ''}`);
};
let ipN = 0;
const gen = async (payload) => {
  const r = await fetch(BASE + '/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-forwarded-for': `10.0.0.${++ipN}` },
    body: JSON.stringify(payload),
  });
  return (await r.json()).draft || '';
};
const allowed = (d) => ((d.match(/\[allowed: ([^\]]*)\]/) || [])[1] || '').split(' / ');

(async () => {
  let d = await gen({ slug: 'makoons-wakad', rating: 'excellent', language: 'en', answers: { program: ['daycare'], liked: ['teachers'] } });
  ok('Makoons daycare parent → "daycare in Wakad" allowed', allowed(d).includes('daycare in Wakad'), allowed(d).join(', '));
  ok('Makoons daycare parent → preschool-only keywords NOT allowed', !allowed(d).includes('play school in Wakad') && !allowed(d).includes('preschool in Wakad'));
  d = await gen({ slug: 'makoons-wakad', rating: 'good', language: 'mr', answers: { program: ['preschool'], liked: ['teaching'] } });
  ok('Makoons preschool parent → preschool keywords allowed, daycare not', allowed(d).includes('preschool in Wakad') && !allowed(d).includes('daycare in Wakad'), allowed(d).join(', '));
  d = await gen({ slug: 'haemoglobbinn', rating: 'excellent', language: 'en', answers: { services: ['seo'], liked: ['support'] } });
  ok('Haemoglobbinn SEO client → "SEO services in Pune" allowed, branding-only not', allowed(d).includes('SEO services in Pune') && !allowed(d).includes('branding company in Pune'), allowed(d).join(', '));
  d = await gen({ slug: 'dhruta', rating: 'good', language: 'hi', answers: { connection: ['home-buyer'], liked: ['quality'] } });
  ok('Dhruta home buyer → redevelopment keywords NOT allowed', !allowed(d).some((k) => /redevelopment/.test(k)), allowed(d).join(', '));
  d = await gen({ slug: 'dhruta', rating: 'excellent', language: 'en', answers: { connection: ['redevelopment'] } });
  ok('Dhruta society member → redevelopment keyword allowed', allowed(d).includes('society redevelopment in Pune'));
  d = await gen({ slug: 'jatan', rating: 'excellent', language: 'en', answers: { liked: ['quality'] } });
  ok('Jatan → unrestricted keyword allowed', allowed(d).includes('2 BHK flats in Sahakar Nagar'));
  ok('Facts sent to AI are only the selections', /What I liked: [^;\]]*quality/i.test(d) && !/Professional team/.test(d), d);

  // keyword usage stats
  const login = await fetch(BASE + '/api/admin/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: process.env.ADMIN_PASSWORD }),
  });
  const cookie = login.headers.get('set-cookie')?.split(';')[0];
  const st = await (await fetch(BASE + '/api/admin/businesses', { headers: { cookie } })).json();
  ok('Keyword usage counted in stats', (st.stats['makoons-wakad'].keywords['daycare in Wakad'] || 0) >= 1, JSON.stringify(st.stats['makoons-wakad'].keywords));

  // admin can switch a keyword off → no longer allowed
  const biz = (await (await fetch(BASE + '/api/admin/businesses/jatan', { headers: { cookie } })).json()).business;
  biz.keywords = biz.keywords.map((k) => (k.text === '2 BHK flats in Sahakar Nagar' ? { ...k, enabled: false } : k));
  const put = await fetch(BASE + '/api/admin/businesses/jatan', { method: 'PUT', headers: { 'Content-Type': 'application/json', cookie }, body: JSON.stringify(biz) });
  ok('Admin saves keyword change', put.ok);
  d = await gen({ slug: 'jatan', rating: 'excellent', language: 'en', answers: { liked: ['quality'] } });
  ok('Switched-off keyword is no longer used', !allowed(d).includes('2 BHK flats in Sahakar Nagar'), allowed(d).join(', '));
  biz.keywords = biz.keywords.map((k) => ({ ...k, enabled: true }));
  await fetch(BASE + '/api/admin/businesses/jatan', { method: 'PUT', headers: { 'Content-Type': 'application/json', cookie }, body: JSON.stringify(biz) });

  console.log(`\n${pass}/${pass + fail} keyword checks passed`);
  process.exit(fail ? 1 : 0);
})();
