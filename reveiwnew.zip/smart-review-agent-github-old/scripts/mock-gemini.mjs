// Fake Gemini server for automated tests (no API key or cost).
// Start:  node scripts/mock-gemini.mjs   (port 3999)
// Then run the app with GEMINI_API_KEY=test GEMINI_API_BASE=http://localhost:3999
// It answers like Gemini, echoing what the real prompt allowed, so tests can check the rules.
import http from 'node:http';

let n = 0;
http
  .createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      n++;
      const b = JSON.parse(body || '{}');
      const sys = b.systemInstruction?.parts?.[0]?.text || '';
      const user = b.contents?.[0]?.parts?.[0]?.text || '';
      const name = (sys.match(/business name "([^"]+)"/) || [])[1] || '?';
      const kws = ((sys.match(/search phrases, only where it reads naturally: ([^.]+)\./) || [])[1] || '')
        .split(' | ')
        .filter(Boolean);
      const lang = (sys.match(/write the whole review in (\w+)/) || [])[1] || 'English';
      const sel = (user.match(/CUSTOMER SELECTIONS:\n([\s\S]*?)\nCUSTOMER'S OWN WORDS/) || [])[1] || '';
      const dev = lang === 'Marathi' ? ' अनुभव छान होता.' : lang === 'Hindi' ? ' अनुभव अच्छा रहा.' : '';
      const text =
        `Mock review ${n}: my experience with ${name} was good${kws[0] ? `, a ${kws[0]} worth noting` : ''}.${dev}` +
        ` [allowed: ${kws.join(' / ') || 'none'}] [facts: ${sel.replace(/\n/g, ' ; ')}]`;
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text }] } }] }));
    });
  })
  .listen(Number(process.env.MOCK_PORT || 3999), () => console.log('mock Gemini on', process.env.MOCK_PORT || 3999));
