import { notFound } from 'next/navigation';
import { getBusiness } from '@/lib/store';
import { publicBusiness } from '@/lib/validate';
import { isAdmin } from '@/lib/auth';
import ChatAgent from '@/components/ChatAgent';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const b = await getBusiness(slug);
  return { title: b ? `Share your feedback – ${b.short_name || b.name}` : 'Not found' };
}

export default async function ReviewPage({ params, searchParams }) {
  const { slug } = await params;
  const sp = await searchParams;
  const b = await getBusiness(slug);
  if (!b) notFound();
  const preview = sp?.preview === '1' && (await isAdmin());
  return <ChatAgent business={publicBusiness(b)} preview={preview} source={sp?.s === 'qr' ? 'qr' : 'link'} />;
}
