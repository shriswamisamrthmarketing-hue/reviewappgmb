import Link from 'next/link';

export default function Home() {
  return (
    <main className="center-page">
      <div className="card narrow">
        <h1>Smart Review Agent</h1>
        <p className="muted">
          Customers reach their business’s feedback assistant by scanning its QR code.
        </p>
        <Link className="btn primary" href="/admin">Open admin dashboard</Link>
      </div>
    </main>
  );
}
