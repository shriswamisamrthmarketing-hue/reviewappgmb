import { NextResponse } from 'next/server';
import { isAdmin } from '@/lib/auth';
import { listBusinesses, getStats, storageMode } from '@/lib/store';
import { DEFAULT_MODEL } from '@/lib/review';

export const dynamic = 'force-dynamic';

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const [businesses, stats] = await Promise.all([listBusinesses(), getStats()]);
    return NextResponse.json({
      businesses,
      stats,
      storage: storageMode(),
      ai: Boolean(process.env.GEMINI_API_KEY),
      model: process.env.GEMINI_MODEL || DEFAULT_MODEL,
    });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
